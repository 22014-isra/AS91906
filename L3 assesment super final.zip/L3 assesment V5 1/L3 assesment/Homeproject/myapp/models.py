from datetime import timedelta # imports time delta from datetime, used to add/subtract weeks/days 
from django.core.exceptions import ValidationError # imports Validation Error from django core exceptions, used to create custom validation errors 
from django.db import models # imports models from django.db, orginal classes
from django.utils import timezone # imports timezone from django.utils, gives a time variable date/time
from datetime import datetime # imports datetime used as a date and time variable

def default_return_date(): # defines a helper function to calculate a default due date for issued books 
    return timezone.now().date() + timedelta(weeks=3) # sets return date to 3 weeks from day of issue

def default_max_issues_allowed(): # defines a helper function to calculate a default mac issued allowed for issued books 
    return 3 # Returns 3 as the default max issues allowed, enforcing a consistent borrowing policy

#22014, password is 22014
# this model is for creating genre classes for books
class Genre(models.Model): #  # Defines the Genre model representing book categories in the database
    genre_id = models.AutoField(primary_key=True) # Auto‑incrementing primary key uniquely identifying each genre
    genre_name = models.CharField(max_length=20, blank=False, # stores the name of the genre, with a max characther lenght, and not being able to leave it blank
        error_messages={ # custom error messeage for blank input
            'blank': "Genre name cannot be empty. Please enter a genre name to continue."
        }
    )
    
    class Meta: # Meta class used to define additional database constraints
        constraints = [
            models.UniqueConstraint( # Ensures no two genres share the same name
                fields=['genre_name'],  # Applies uniqueness to the genre_name field
                name='unique_genre_name' # Names the constraint for easier debugging
            )
        ]

    def clean(self): # this creates custom validation methods to excute before saving the model
        super().clean() # Calls the parent clean method to ensure any built‑in validation is executed first
        #empty check, space inputs
        if not self.genre_name or not self.genre_name.strip(): # Checks if genre_name is empty or contains only whitespace
            raise ValidationError({ # Raises a validation error with a custom message if the genre name is invalid
                'genre_name': "Genre name cannot be empty. Please enter a genre name to continue."
            })
        # 2 Friendly validation error for duplicates
        if Genre.objects.filter( # Checks if another genre with the same name
            genre_name__iexact=self.genre_name.strip() # Case‑insensitive match on genre_name, ignoring leading/trailing whitespace
        ).exclude(pk=self.pk).exists(): # Excludes the current instance (if it exists) from the check to allow updates without false positives
            raise ValidationError("This genre already exists in the system.") # Raises a validation error if a duplicate genre name is found
        allowed = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ - 0123456789")  # Defines a set of allowed characters for the genre name  
        if not all (char in allowed for char in self.genre_name):# Checks if all characters in the genre name are within the allowed set, ensuring no special characters are used
           raise ValidationError ("Genre name can only be letters, numebers and - , please enter Letters, numbers or - to create a Genre") # Raises a validation error if any invalid characters are found in the genre name
# 
# 
    def __str__(self): # Defines the string representation of the Genre model
        return self.genre_name # Returns the genre name as the string representation of the Genre object
    
# this model is for creating users who want to issue/return books/ use the system
class User(models.Model): # Defines the User model representing library users in the database
    user_id = models.AutoField(primary_key=True) # Auto‑incrementing primary key uniquely identifying each user
    first_name = models.CharField(max_length=20) # Stores the user's first name, with a maximum length of 20 characters
    last_name = models.CharField(max_length=20) # Stores the user's last name, with a maximum length of 20 characters
    email = models.EmailField(unique=True, blank=False, null=False) # Stores the user's email address, which must be unique and cannot be blank or null
    phone = models.CharField(max_length=15, unique=True, blank=False, null=False) # Stores the user's phone number, which must be unique and cannot be blank or null
    max_issues_allowed = models.PositiveIntegerField(default=default_max_issues_allowed, editable=False) # Stores the maximum number of books the user can issue
    class Meta: # Meta class used to define additional database constraints
        constraints = [ 
            models.UniqueConstraint( # Ensures that the combination of first_name and last_name is unique across all User records
                fields=['first_name', 'last_name'], # Applies uniqueness to the combination of first_name and last_name fields
                name='unique_user_full_name' # Names the constraint for easier debugging and database management
            )
        ]

    def clean(self): # Defines a custom clean method to perform validation before saving the User model
      if not self.first_name.strip(): # Checks if the first name is empty or contains only whitespace
        raise ValidationError("First namecannot be empty, please enter a first name to continue") # Raises a validation error 
      if not self.last_name.strip(): # Checks if the last name is empty or contains only whitespace
        raise ValidationError("Last name cannot be empty, please enter a last name to continue") # Raises a validation error 
      if not self.email.strip(): # Checks if the email is empty or contains only whitespace
        raise ValidationError("Email cannot be empty, please enter an email to continue") # Raises a validation
      if not self.phone.strip(): # Checks if the phone number is empty or contains only whitespace
        raise ValidationError("Phone number cannot be empty, please enter a phone number to continue") #    Raises a validation error 
      allowed = set("0123456789 .-") # Defines a set of allowed characters for the phone number (digits, spaces, periods, and hyphens)
      if not all(char in allowed for char in self.phone): # Checks if all characters in the phone number are within the allowed set
        raise ValidationError("Phone number must contain only, digits, spaces, periods or -,  Letters are not allowed.") # Raises a validation error
      digits_only = ''.join(char for char in self.phone if char.isdigit()) # Extracts only the digits from the phone number to validate the length 
      if len(digits_only) < 9 or len(digits_only) > 15: # Checks if the number of digits in the phone number is between 9 and 15 
        raise ValidationError("Phone number must contain between 9 and 15 digits.") # Raises a validation error  
      if any(char.isdigit() for char in self.first_name): # Checks if any character in the first name is a digit, which is not allowed for names
        raise ValidationError("First name cannot contain numbers.") # Raises a validation error if any digits are found in the first name
      if any(char.isdigit() for char in self.last_name): # Checks if any character in the last name is a digit, which is not allowed for names
        raise ValidationError("Last name cannot contain numbers.")# Raises a validation error if any digits are found in the last name

      if User.objects.filter( # Checks if another user with the same first and last name (case‑insensitive) already exists in the database 
            first_name__iexact=self.first_name.strip(), #   Case‑insensitive match on first_name, ignoring leading/trailing whitespace
            last_name__iexact=self.last_name.strip()  
        ).exclude(pk=self.pk).exists(): # Excludes the current instance (if it exists) from the check to allow updates without false positives  
            raise ValidationError("A user with this first and last name already exists.") # Raises a validation error  
         

    def __str__(self): # Defines the string representation of the User model 
        return self.first_name + " " + self.last_name # Returns the user's full name (first name and last name)  

#this model if for creating book classes for users to issue and return 
class Book(models.Model): # Defines the Book model representing books in the library's collection in the database
    book_id = models.AutoField(primary_key=True) # Auto‑incrementing primary key uniquely identifying each book
    title = models.CharField(max_length=30) # Stores the title of the book, with a maximum length of 30 characters
    author = models.CharField(max_length=20) # Stores the author of the book, with a maximum length of 20 characters
    genre = models.ForeignKey(Genre, on_delete=models.CASCADE, null=True, blank=False) # Establishes a foreign key relationship to the Genre model 
    year_published = models.DateField(blank=True, null=True) # Stores the year the book was published as a date field 
    copies = models.PositiveIntegerField(default=1) # Stores the total number of copies of the book available in the library

    class Meta: # Meta class used to define additional database constraints
        constraints = [ # Defines a unique constraint to ensure that no two books can have the same title and author combination 
            models.UniqueConstraint( # Ensures that the combination of title and author is unique across all Book records
                fields=['title', 'author'], # Applies uniqueness to the combination of title and author fields
                name='unique_book_title_author' # Names the constraint for easier debugging and database management
            )
        ]
    def copies_issued(self): # Helper method to calculate the number of copies currently issued for this book by counting related BookIssue records   
        if self.pk: #   Checks if the book instance has a primary key before attempting to count issued copies 
            return BookIssue.objects.filter(book=self).count() # Counts the number of BookIssue records that are related to this book 
        return 0 # If the book instance does not have a primary key, returns 0 as there can be no issued copies for an unsaved book

    
    def copies_available(self): # Helper method to calculate the number of copies currently available  
        if self.pk: # Checks if the book instance has a primary key  
            return max(self.copies - self.copies_issued(), 0) # Calculates the number of available copies by subtracting the number of issued copies from the total copies
        return self.copies # If the book instance does not have a primary key  
    
    def clean(self): # Defines a custom clean method to perform validation before saving the Book model
            # Title empty
        if not self.title or not self.title.strip(): # Checks if the title is empty or contains only whitespace
            raise ValidationError({ # Raises a validation error with a custom message if the title is invalid 
                'title': "Book title cannot be empty. Please enter a title to continue."  
            })

        # Author empty
        if not self.author or not self.author.strip(): # Checks if the author is empty or contains only whitespace
            raise ValidationError({ # Raises a validation error with a custom message if the author is invalid #
                'author': "Author name cannot be empty. Please enter an author to continue."  
            })

        # Genre empty
        if not self.genre: # Checks if the genre is not set 
            raise ValidationError({ # Raises a validation error  
                'genre': "Please select a genre for this book." 
            })

        # Copies cannot be zero
        if self.copies is None or self.copies <= 0: # Checks if the number of copies is None or less than or equal to 0 
            raise ValidationError({ # Raises a validation error with a custom message if the number of copies is invalid  
                'copies': "Copies must be at least 1. A book cannot have zero copies."  
            })

        # Year published cannot be in the future
        if self.year_published and self.year_published > timezone.now().date(): # Checks if the year published is set and is greater than the current date   
            raise ValidationError({ # Raises a validation error 
                'year_published': "Year published cannot be in the future."   
            }) 

        if not self.year_published: # Checks if the year published is not set  
            raise ValidationError({ # Raises a validation error  
                'year_published': "Year published cannot be empty, please enter a date" # Custom error message  
           })  

        if Book.objects.filter( # Checks if another book with the same title and author (case‑insensitive) already exists in the database 
            title__iexact=self.title.strip(), # Case‑insensitive match on title, ignoring leading/trailing whitespace
            author__iexact=self.author.strip() 
        ).exclude(pk=self.pk).exists(): # Excludes the current instance (if it exists) from the check to allow updates without false positives
            raise ValidationError("This book already exists in the system.") #
        
        if self.copies < self.copies_issued(): #    Checks if the number of copies is less than the number of copies currently issued 
            raise ValidationError({ # Raises a validation error   
                'copies': f"Cannot set copies below currently issued count ({self.copies_issued()})." # Custom error message  
            }) 

    def __str__(self): # Defines the string representation of the Book model 
        return self.title + " by " + self.author # Returns the book's title and author as the string representation of the Book object 

# this model is for creating bookissue classes for when users want to issue a book
class BookIssue(models.Model): # Defines the BookIssue model representing the issuance of books to users in the library   
  issue_id = models.AutoField(primary_key=True) # Auto‑incrementing primary key uniquely identifying each book issue record
  user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=False) #    Establishes a foreign key relationship to the User model  
  book = models.ForeignKey(Book, on_delete=models.CASCADE, null=True, blank=False) # Establishes a foreign key relationship to the Book model 
  issue_date = models.DateField(auto_now_add=True) # Stores the date when the book was issued, automatically set to the current date when the record is created and not editable thereafter
  return_by = models.DateField(default=default_return_date, blank=True, null=True, editable=False) # Stores the date by which the book should be returned,   
  max_issues_allowed = models.PositiveIntegerField(default=default_max_issues_allowed, editable=False) # Stores the maximum number of issues allowed for the user at the time of issuing the book 

  def __str__(self):# Defines the string representation of the BookIssue model
    return f"{self.user} issued {self.book} on {self.issue_date} return date {self.return_by}" # Returns a string that includes the user's name 
  
  def clean(self): # Defines a custom clean method to perform validation before saving the BookIssue model  
    if not self.user: # Checks if the user field is not set  
        raise ValidationError({ # Raises a validation error  
            'user': "Please select a user to issue the book."  
        })
    if not self.book: # Checks if the book field is not set  
        raise ValidationError({ # Raises a validation error 
            'book': "Please select a book to issue."  
        })   
    if self.user and self.user.max_issues_allowed <= 0: # Checks if the user is set and their max_issues_allowed is less than or equal to 0 
        raise ValidationError({ # Raises a validation error with a custom message if the user has no remaining issues allowed   
            'user': f"{self.user} has no remaining issues" # Custom error message indicating that the user has no remaining issues allowed   
        })

    if self.book: # Checks if the book field is set before performing availability validation 
      issued_count = BookIssue.objects.filter(book=self.book).exclude(pk=self.pk).count() # Counts the number of BookIssue records for the selected book  
      if issued_count >= self.book.copies: # Checks if the number of issued copies is greater than or equal to the total number of copies available for the book 
        raise ValidationError({ # Raises a validation error with a custom message if there are no copies of the book available for issue 
            'book': f"No copies of '{self.book.title}' are available for issue." # Custom error message indicating that there are no copies of the selected book available for issue 
        })  
    super().clean() # Calls the parent clean method to ensure any built‑in validation is executed after the custom validation logic 

  def save(self, *args, **kwargs): # Overrides the save method to include custom logic for handling the issuance of books 
    is_new = self.pk is None  # Determines if the book issue record is being created for the first time  

    self.full_clean() # Calls full_clean to perform validation before saving the record   
  
    if not self.issue_date: # Checks if the issue_date is not set (i.e., it is None)   
        self.issue_date = timezone.now().date() # Sets the issue_date to the current date if it is not already set   

    if is_new: # Checks if the book issue record is being created for the first time to set the return_by date based on the issue_date  
        # Set return date only on creation #    
        self.return_by = self.issue_date + timedelta(weeks=3) # Sets the return_by date to be 3 weeks from the issue_date  

    super().save(*args, **kwargs) # Calls the parent save method to save the book issue record to the database after all custom logic and validation has been executed 

    # After saving the issue, reduce user's max_issues_allowed
    if is_new: # Checks if the book issue record is being created for the first time to update the user's max_issues_allowed  
        user = self.user # Retrieves the user associated with the book issue record to update their max_issues_allowed  
        if user.max_issues_allowed > 0: # Checks if the user's max_issues_allowed is greater than 0 before decrementing it 
            user.max_issues_allowed -= 1 # Decrements the user's max_issues_allowed by 1 to reflect that they have issued a book   
            user.save() # Saves the updated user record to the database after modifying max_issues_allowed

    if is_new: # Checks if the book issue record is being created for the first time to create a BorrowRecord for tracking the issue and return of the book   
        BorrowRecord.objects.create( # Creates a new BorrowRecord to track the borrowing of the book 
            user=self.user, # Associates the BorrowRecord with the user who issued the book 
            book=self.book, # Associates the BorrowRecord with the book that was issued 
            issue_date=self.issue_date, # Sets the issue_date of the BorrowRecord to match the issue_date of the BookIssue 
    ) 


# this model if for bookretun classes, for when a user wants to return a issued book
class BookReturn(models.Model): # Defines the BookReturn model representing the return of books by users in the library   
   return_id = models.AutoField(primary_key=True) # Auto‑incrementing primary key uniquely identifying each book return record
   user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=False) # Establishes a foreign key relationship to the User model 
   book = models.ForeignKey(Book, on_delete=models.CASCADE, null=True, blank=False) # Establishes a foreign key relationship to the Book model   
   return_date = models.DateField( null=True, blank=False) # Stores the date when the book was returned   
 
   def clean(self): # Defines a custom clean method to perform validation before saving the BookReturn model  
       super().clean() # Calls the parent clean method to ensure any built‑in validation is executed first  
       if not self.user: # Checks if the user field is not set  
           raise ValidationError({ 
               'user': "Please select a user. A return must be linked to a user."  
           })

       # Book empty 
       if not self.book: # Checks if the book field is not set 
           raise ValidationError({ #    Raises a validation error  
               'book': "Please select a book. Only issued books can be returned." 
           })
       if not self.return_date: # Checks if the return_date is not set  
           raise ValidationError({ # Raises a validation error  
              'return_date':"please enter a return date to continue"  
           })
       
       if self.user and self.book: # Checks if both the user and book fields are set before performing validation  
           active_issue = BookIssue.objects.filter(user=self.user, book=self.book).first() # Checks if there is an active BookIssue for the given user and book  
           if not active_issue: # If no active BookIssue is found for the user and book  
               raise ValidationError({ # Raises a validation error  
                   'book': f"This user has not issued '{self.book.title}'. Only issued books can be returned."  
               })
       record = BorrowRecord.objects.filter( # Retrieves the active BorrowRecord for the given user and book 
           user=self.user, # Filters BorrowRecord records to find those that match the user associated with the book return
           book=self.book, # Filters BorrowRecord records to find those that match the book associated with the book return 
           return_date__isnull=True # Filters BorrowRecord records to find those where the return_date is null  
        ).first() # Retrieves the first BorrowRecord that matches the specified filters  
       
       return_date = self.return_date # Retrieves the return_date from the BookReturn instance to validate it against the issue_date from the BorrowRecord  
       issue_date = record.issue_date # Retrieves the issue_date from the BorrowRecord to validate it against the return_date from the BookReturn 

       if isinstance(return_date, datetime): # Checks if the return_date is an instance of datetime  
          return_date = return_date.date() # If the return_date is a datetime object  

       if isinstance(issue_date, datetime): # Checks if the issue_date is an instance of datetime  
           issue_date = issue_date.date() # If the issue_date is a datetime object   

       if return_date < issue_date: # Checks if the return_date is earlier than the issue_date  
           raise ValidationError({ # Raises a validation error  
               'return_date': "Return date cannot be earlier than the issue date." # Custom error message   
           })

   def save(self, *args, **kwargs): # Overrides the save method to include custom logic for handling the return of books  
       is_new  = self.pk is None # Determines if the book return record is being created for the first time 

       self.full_clean() # Calls full_clean to perform validation before saving the record  
       super().save(*args, **kwargs) # Calls the parent save method to save the book return record to the database after all custom logic and validation has been executed    
       # Remove the active BookIssue and update BorrowRecord after return
       record = None # Initializes the record variable to None  
       if is_new: # Checks if the book return record is being created for the first time to perform the necessary actions for processing the return 
          active_issue = BookIssue.objects.filter(user=self.user, book=self.book # Checks for an active BookIssue for the given user and book  
          ).order_by('issue_date').first() # Orders the BookIssue records by issue_date to ensure that if there are multiple issues of the same book by the same user  
          if active_issue: #    Checks if an active BookIssue was found for the user and book  
              active_issue.delete() # Deletes the active BookIssue record to reflect that the book has been returned

          record = BorrowRecord.objects.filter(  # Retrieves the active BorrowRecord for the given user and book  
              user=self.user, # Filters BorrowRecord records to find those that match the user associated with the book return  
              book=self.book, # Filters BorrowRecord records to find those that match the book associated with the book return 
              return_date__isnull=True # Filters BorrowRecord records to find those where the return_date is null  
          ).first() # Retrieves the first BorrowRecord that matches the specified filters   
          if record: # Checks if a valid BorrowRecord was found for the user and book  
              record.return_date = self.return_date # Updates the return_date of the BorrowRecord to match the return_date of the BookReturn  
              
              record.save() # Saves the updated BorrowRecord to the database after setting the return_date   


       if record: # Checks if a valid BorrowRecord was found for the user and book    
        due_date = record.issue_date + timedelta(weeks=3) # Calculates the due date for the borrowed book based on the issue_date from the BorrowRecord 

        if self.return_date > due_date: # Checks if the return_date from the BookReturn is later than the calculated due_date  
            # Returned late → calculate fine
            days_late = (self.return_date - due_date).days # Calculates the number of days late   
            record.fine_amount = days_late * 0.50 # Calculates the fine amount  
        else: # 
            # Returned on time → fine stays 0.00  
            record.fine_amount = 0.00 # Sets the fine_amount to 0.00 for returns that are made on time 
 
        record.save() # Saves the updated BorrowRecord to the database after calculating the fine amount (if applicable) 

        user = self.user # Retrieves the user associated with the book return to update their max_issues_allowed   
        user.max_issues_allowed += 1 # Increments the user's max_issues_allowed by 1 to reflect that they have returned a book  
        user.save() # Saves the updated user record to the database after modifying max_issues_allowed  


   def __str__(self): # Defines the string representation of the BookReturn model  
    user = self.user if hasattr(self, "user") else "Unknown user" # Retrieves the user associated with the book return   
    book = self.book if hasattr(self, "book") else "Unknown book" # Retrieves the book associated with the book return   
    return f"{user} returned {book} on {self.return_date}" # Returns a string that includes the user's name, the book's title, and the return date  
   
  
# this model is for borrow record history classes and shows which user issued what book, when they returned it and what fines they have.       
class BorrowRecord(models.Model): # Defines the BorrowRecord model representing the history of book borrowings by users in the library  
    record_id = models.AutoField(primary_key=True) # Auto‑incrementing primary key uniquely identifying each borrow record
    book = models.ForeignKey(Book, on_delete=models.CASCADE) # Establishes a foreign key relationship to the Book model 
    user = models.ForeignKey(User, on_delete=models.CASCADE) # Establishes a foreign key relationship to the User model  
    issue_date = models.DateField(auto_now_add=True) # Stores the date when the book was issued   
    return_date = models.DateField(blank=True, null=True) # Stores the date when the book was returned  
    fine_amount = models.DecimalField(max_digits=6, decimal_places=2, default=0.00) # Stores the fine amount for late returns 
    def __str__(self): # Defines the string representation of the BorrowRecord model  
        return f"{self.user} borrowed {self.book} on {self.issue_date} and returned on {self.return_date}" # Returns a string that includes the user's name 