from django import forms # Imports the forms module from Django, which provides tools for creating and handling forms in the application 
from django.contrib import admin # Imports the admin module from Django   
from django.core.exceptions import ValidationError # Imports the ValidationError exception from Django's core exceptions module  
from django.db import models # Imports the models module from Django, which provides tools for defining the data models for the application  

from .models import Genre, User, Book, BookIssue, BookReturn, BorrowRecord # Imports the data models defined in the models.py file of the same application

# this class is for borrow record, which is used to keep track of the borrowing history of books by users 
class BorrowRecordAdmin(admin.ModelAdmin): # Defines a custom admin class for the BorrowRecord model  
    list_display = ('user', 'book', 'issue_date', 'return_date', 'fine_amount') # Specifies the fields to display in the list view of the BorrowRecord model in the admin interface  
    readonly_fields = ('fine_amount',) # Specifies that the fine_amount field is read-only in the admin interface, preventing library staff from manually editing the fine amount for borrow records  

    def has_add_permission(self, request): # Overrides the default permission to add new borrow records in the admin interface   
        return False # Returns False to indicate that adding new borrow records through the admin interface is not allowed 

    def has_change_permission(self, request, obj=None): # Overrides the default permission to change existing borrow records in the admin interface  
        return False # Returns False to indicate that changing existing borrow records through the admin interface is not allowed 

    # # def has_delete_permission(self, request, obj=None):
    # #     return False
# this class is for user, which is used to represent the users of the library system 
class UserAdmin(admin.ModelAdmin): # Defines a custom admin class for the User model 
    readonly_fields = ('max_issues_allowed',) # Specifies that the max_issues_allowed field is read-only in the admin interface

# this class is for book, which is used to represent the books in the library system
class BookAdmin(admin.ModelAdmin): # Defines a custom admin class for the Book model 
    list_display = ('title', 'author', 'genre', 'copies', 'copies_available') # Specifies the fields to display in the list view of the Book model in the admin interface 
    fields = ('title', 'author', 'genre', 'year_published', 'copies') # Specifies the fields to display in the form view of the Book model in the admin interface  

# this class is for book issue, which is used to represent the records of books being issued to users in the library system
class BookIssueAdmin(admin.ModelAdmin): # Defines a custom admin class for the BookIssue model  
    list_display = ('user', 'book', 'issue_date', 'return_by') # Specifies the fields to display in the list view of the BookIssue model in the admin interface 
    readonly_fields = ('issue_date', 'return_by', 'max_issues_allowed') # Specifies that the issue_date, return_by, and max_issues_allowed fields are read-only in the admin interface  
    fields = ('user', 'book', 'return_by') # Specifies the fields to display in the form view of the BookIssue model in the admin interface, allowing library staff to select the user, book, and return by date when creating a new book issue   
 
    def get_changeform_initial_data(self, request): # Overrides the method to provide initial data for the change form when creating a new book issue in the admin interface.   
        initial = super().get_changeform_initial_data(request) # Calls the parent method to get the default initial data for the change form 
        if 'return_by' not in initial: # Checks if the return_by field is not already set in the initial data 
            initial['return_by'] = BookIssue.return_by.field.default() # Sets the default return by date in the initial data for the change form based on the default value defined in the BookIssue model  .
        return initial # Returns the modified initial data for the change form 
    
    def has_change_permission(self, request, obj=None): # Overrides the default permission to change existing book issues in the admin interface  
        return False # Returns False to indicate that changing existing book issues through the admin interface is not allowed 
    
# this class is for book return, which is used to represent the records of books being returned by users in the library system
class BookReturnForm(forms.ModelForm): # Defines a custom form for the BookReturn model  
    class Meta: # Defines the metadata for the BookReturnForm 
        model = BookReturn # Specifies that this form is associated with the BookReturn model
        fields = '__all__' # Specifies that all fields from the BookReturn model should be included in the form 

    def clean(self): # Overrides the clean method to add custom validation logic for the BookReturn form
        cleaned_data = super().clean() # Calls the parent clean method to perform the default cleaning and validation logic
        user = cleaned_data.get('user') # Retrieves the user from the cleaned data to perform validation checks related to the user associated with the book return 
        book = cleaned_data.get('book') # Retrieves the book from the cleaned data to perform validation checks related to the book being returned 
        if user and book: # Checks if both the user and book are present in the cleaned data before performing further validation
            active_issue = BookIssue.objects.filter(user=user, book=book).first() # Queries the BookIssue model to check if there is an active issue record for the selected user and book 
            if not active_issue: # Checks if there is no active issue record for the selected user and book 
                raise ValidationError( # Raises a validation error  
                    f"This user has not issued '{book.title}'. Only issued books can be returned." # Custom error message  
                )
        return cleaned_data # Returns the cleaned data after performing the custom validation checks 
 
 # this class is for book return, which is used to represent the records of books being issued and returned by users in the library system
class BookReturnAdmin(admin.ModelAdmin):  # Defines a custom admin class for the BookReturn model
    form = BookReturnForm #     Specifies that the BookReturnForm should be used for creating and editing book return records in the admin interface 
    list_display = ('user', 'book', 'return_date')  #    Specifies the fields to display in the list view of the BookReturn model in the admin interface  
    def formfield_for_foreignkey(self, db_field, request, **kwargs): # Overrides the method to customize the form field for foreign key relationships in the admin interface
        if db_field.name == "book": # Checks if the foreign key field being processed is the book field 
            # Only show books that still have at least one active issue 
            kwargs["queryset"] = Book.objects.annotate(  # Annotates the Book queryset with a count of active issues for each book  
                active_issues=models.Count('bookissue') # Counts the number of related BookIssue records for each Book
            ).filter(active_issues__gt=0) # Filters the annotated queryset to include only books that have more than 0 active issues
        return super().formfield_for_foreignkey(db_field, request, **kwargs) # Calls the parent method to get the default form field for the foreign key  
     
    def has_change_permission(self, request, obj=None): # Overrides the default permission to change existing book return records in the admin interface  
        return False # Returns False to indicate that changing existing book return records through the admin interface is not allowed 

admin.site.register(Genre)  # Registers the Genre model with the Django admin site, 
admin.site.register(User, UserAdmin) #  Registers the User model with the Django admin site using the custom UserAdmin class  
admin.site.register(Book, BookAdmin) # Registers the Book model with the Django admin site using the custom BookAdmin class 
admin.site.register(BookIssue, BookIssueAdmin) # Registers the BookIssue model with the Django admin site using the custom BookIssueAdmin class 
admin.site.register(BookReturn, BookReturnAdmin) # Registers the BookReturn model with the Django admin site using the custom BookReturnAdmin class  
admin.site.register(BorrowRecord, BorrowRecordAdmin) # Registers the BorrowRecord model with the Django admin site using the custom BorrowRecordAdmin class
  