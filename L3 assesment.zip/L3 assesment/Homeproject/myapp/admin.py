from django.contrib import admin

from .models import Genre, User, Book

admin.site.register(Genre)
admin.site.register(User)
admin.site.register(Book)
# Register your models here.
