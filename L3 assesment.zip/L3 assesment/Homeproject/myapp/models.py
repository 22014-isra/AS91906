from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator
from django.db import models

#22014, password is 22014

class Genre(models.Model):
    genre_id = models.AutoField(primary_key=True)
    genre_name = models.CharField(max_length=100)
    def __str__(self):
        return self.genre_name
    
    # def clean(self):
    #    if not self.genre_name.strip():
    #     raise ValidationError("Genre name cannot be empty, please enter a Genre name to continue")
    #    allowed = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ -")
    #    if not all(char in allowed for char in self.genre_name):
    #     raise ValidationError("Genre name must contain only letters,please enter the genre name using only letters to continue")
    #    if self.genre_id is None:
    #     raise ValidationError("Genre cannot be empty,please select a genre to continue ")
    #    duplicate = Genre.objects.filter(
    #       genre_name__iexact=self.genre_name.strip(),
    #    ).exclude(pk=self.pk)

class User(models.Model):
    user_id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True, blank=False, null=False)
    phone = models.CharField(max_length=15, blank=False, null=False)
    max_books_allowed = models.IntegerField(validators=[MaxValueValidator(3)])
    def clean(self):
      if not self.first_name.strip():
        raise ValidationError("First namecannot be empty, please enter a first name to continue")
      if not self.last_name.strip():
        raise ValidationError("Last name cannot be empty, please enter a last name to continue")
      if not self.email.strip():
        raise ValidationError("Email cannot be empty, please enter an email to continue")
      if not self.phone.strip():
        raise ValidationError("Phone number cannot be empty, please enter a phone number to continue")
      allowed = set("0123456789 -.")
      if not all(char in allowed for char in self.phone):
        raise ValidationError("Phone number must contain only, digits, spaces, periods or -,  Letters are not allowed.")
      
      def __str__(self):
        return self.first_name + " " + self.last_name


class Book(models.Model):
    book_id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=100)
    author = models.CharField(max_length=100)
    genre = models.ForeignKey(Genre, on_delete=models.CASCADE)
    year_published = models.IntegerField(blank=True, null=True)
    is_borrowed = models.BooleanField(default=False)
    def __str__(self):
        return self.title + " by " + self.author