from datetime import timedelta # imports time delta from datetime, used to add/subtract weeks/days 
from django.core.exceptions import ValidationError # imports Validation Error from django core exceptions, used to create custom validation errors 
from django.db import models # imports models from django.db, orginal classes
from django.utils import timezone # imports timezone from django.utils, gives a time variable date/time
from datetime import datetime # imports datetime used as a date and time variable

def default_return_date(): # defines a helper function to calculate a default due date for issued books 
    return timezone.now().date() + timedelta(weeks=3) # sets return date to 3 weeks from day of issue

def default_max_issues_allowed(): # defines a helper function to calculate a default mac issued allowed for issued books 
    return 3 # Returns 3 as the default max issues allowed, enforcing a consistent borrowing policy

#22014, password is 22014

class Genre(models.Model): #  # Defines the Genre model representing book categories in the database
    genre_id = models.AutoField(primary_key=True) # Auto‑incrementing primary key uniquely identifying each genre
    genre_name = models.CharField(max_length=20, blank=False, # stores the name of the genre, with a max characther lenght, and not being able to leave it blank
        error_messages={ # custom error messeage for blank input
            'blank': "Genre name cannot be empty. Please enter a genre name to continue."
        }
    )
    
    class Meta: # Meta class used to define additional database constraints
        constraints = [
            models.UniqueConstraint( # Ensures no two genres share the same name
                fields=['genre_name'],  # Applies uniqueness to the genre_name field
                name='unique_genre_name' # Names the constraint for easier debugging
            )
        ]

    def clean(self): # this creates custom validation methods to excute before saving the model
        super().clean() # Calls the parent clean method to ensure any built‑in validation is executed first
        #empty check, space inputs
        if not self.genre_name or not self.genre_name.strip(): # Checks if genre_name is empty or contains only whitespace
            raise ValidationError({ # Raises a validation error with a custom message if the genre name is invalid
                'genre_name': "Genre name cannot be empty. Please enter a genre name to continue."
            })
        # 2 Friendly validation error for duplicates
        if Genre.objects.filter( # Checks if another genre with the same name (case‑insensitive) already exists in the database, excluding the current instance
            genre_name__iexact=self.genre_name.strip() # Case‑insensitive match on genre_name, ignoring leading/trailing whitespace
        ).exclude(pk=self.pk).exists(): # Excludes the current instance (if it exists) from the check to allow updates without false positives
            raise ValidationError("This genre already exists in the system.") # Raises a validation error if a duplicate genre name is found
        allowed = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ - 0123456789")  # Defines a set of allowed characters for the genre name (letters, numbers, spaces, and hyphens)
        if not all (char in allowed for char in self.genre_name):# Checks if all characters in the genre name are within the allowed set, ensuring no special characters are used
           raise ValidationError ("Genre name can only be letters, numebers and - , please enter Letters, numbers or - to create a Genre") # Raises a validation error if any invalid characters are found in the genre name
# 
# 
    def __str__(self): # Defines the string representation of the Genre model, which is used in the Django admin and other places where the object is represented as a string
        return self.genre_name # Returns the genre name as the string representation of the Genre object, making it easier to identify genres in lists and dropdowns
    

class User(models.Model): # Defines the User model representing library users in the database
    user_id = models.AutoField(primary_key=True) # Auto‑incrementing primary key uniquely identifying each user
    first_name = models.CharField(max_length=20) # Stores the user's first name, with a maximum length of 20 characters
    last_name = models.CharField(max_length=20) # Stores the user's last name, with a maximum length of 20 characters
    email = models.EmailField(unique=True, blank=False, null=False) # Stores the user's email address, which must be unique and cannot be blank or null
    phone = models.CharField(max_length=15, unique=True, blank=False, null=False) # Stores the user's phone number, which must be unique and cannot be blank or null
    max_issues_allowed = models.PositiveIntegerField(default=default_max_issues_allowed, editable=False) # Stores the maximum number of books the user can issue, with a default value set by the helper function and not editable in the admin interface
    class Meta: # Meta class used to define additional database constraints
        constraints = [ # Defines a unique constraint to ensure that no two users can have the same first and last name combination, enhancing data integrity and preventing duplicate user entries
            models.UniqueConstraint( # Ensures that the combination of first_name and last_name is unique across all User records
                fields=['first_name', 'last_name'], # Applies uniqueness to the combination of first_name and last_name fields
                name='unique_user_full_name' # Names the constraint for easier debugging and database management
            )
        ]

    def clean(self): # Defines a custom clean method to perform validation before saving the User model
      if not self.first_name.strip(): # Checks if the first name is empty or contains only whitespace
        raise ValidationError("First namecannot be empty, please enter a first name to continue") # Raises a validation error with a custom message if the first name is invalid
      if not self.last_name.strip(): # Checks if the last name is empty or contains only whitespace
        raise ValidationError("Last name cannot be empty, please enter a last name to continue") # Raises a validation error with a custom message if the last name is invalid
      if not self.email.strip(): # Checks if the email is empty or contains only whitespace
        raise ValidationError("Email cannot be empty, please enter an email to continue") # Raises a validation error with a custom message if the email is invalid
      if not self.phone.strip(): # Checks if the phone number is empty or contains only whitespace
        raise ValidationError("Phone number cannot be empty, please enter a phone number to continue") #    Raises a validation error with a custom message if the phone number is invalid
      allowed = set("0123456789 .-") # Defines a set of allowed characters for the phone number (digits, spaces, periods, and hyphens)
      if not all(char in allowed for char in self.phone): # Checks if all characters in the phone number are within the allowed set, ensuring that only valid characters are used in the phone number
        raise ValidationError("Phone number must contain only, digits, spaces, periods or -,  Letters are not allowed.") # Raises a validation error if any invalid characters are found in the phone number
      digits_only = ''.join(char for char in self.phone if char.isdigit()) # Extracts only the digits from the phone number to validate the length, allowing for formatting characters in the input
      if len(digits_only) < 9 or len(digits_only) > 15: # Checks if the number of digits in the phone number is between 9 and 15, which is a common range for valid phone numbers internationally
        raise ValidationError("Phone number must contain between 9 and 15 digits.") # Raises a validation error if the phone number does not contain a valid number of digits
      if any(char.isdigit() for char in self.first_name): # Checks if any character in the first name is a digit, which is not allowed for names
        raise ValidationError("First name cannot contain numbers.") # Raises a validation error if any digits are found in the first name
      if any(char.isdigit() for char in self.last_name): # Checks if any character in the last name is a digit, which is not allowed for names
        raise ValidationError("Last name cannot contain numbers.")# Raises a validation error if any digits are found in the last name

      if User.objects.filter( # Checks if another user with the same first and last name (case‑insensitive) already exists in the database, excluding the current instance
            first_name__iexact=self.first_name.strip(), #   Case‑insensitive match on first_name, ignoring leading/trailing whitespace
            last_name__iexact=self.last_name.strip() # Case‑insensitive match on last_name, ignoring leading/trailing whitespace
        ).exclude(pk=self.pk).exists(): # Excludes the current instance (if it exists) from the check to allow updates without false positives  
            raise ValidationError("A user with this first and last name already exists.") # Raises a validation error if a duplicate user with the same first and last name combination is found in the system
         

    def __str__(self): # Defines the string representation of the User model, which is used in the Django admin and other places where the object is represented as a string
        return self.first_name + " " + self.last_name # Returns the user's full name (first name and last name) as the string representation of the User object, making it easier to identify users in lists and dropdowns


class Book(models.Model): # Defines the Book model representing books in the library's collection in the database
    book_id = models.AutoField(primary_key=True) # Auto‑incrementing primary key uniquely identifying each book
    title = models.CharField(max_length=30) # Stores the title of the book, with a maximum length of 30 characters
    author = models.CharField(max_length=20) # Stores the author of the book, with a maximum length of 20 characters
    genre = models.ForeignKey(Genre, on_delete=models.CASCADE, null=True, blank=False) # Establishes a foreign key relationship to the Genre model, allowing each book to be associated with a genre. If the genre is deleted, the related books will also be deleted (CASCADE). The genre field cannot be blank but can be null in the database.
    year_published = models.DateField(blank=True, null=True) # Stores the year the book was published as a date field, allowing for blank and null values to accommodate cases where the publication year is unknown or not provided
    copies = models.PositiveIntegerField(default=1) # Stores the total number of copies of the book available in the library, with a default value of 1 and only allowing positive integers

    class Meta: # Meta class used to define additional database constraints
        constraints = [ # Defines a unique constraint to ensure that no two books can have the same title and author combination, enhancing data integrity and preventing duplicate book entries
            models.UniqueConstraint( # Ensures that the combination of title and author is unique across all Book records
                fields=['title', 'author'], # Applies uniqueness to the combination of title and author fields
                name='unique_book_title_author' # Names the constraint for easier debugging and database management
            )
        ]
    def copies_issued(self): # Helper method to calculate the number of copies currently issued for this book by counting related BookIssue records, allowing for dynamic tracking of issued copies without needing a separate field in the database
        if self.pk: #   Checks if the book instance has a primary key (i.e., it has been saved to the database) before attempting to count issued copies, ensuring that the method only operates on valid book records
            return BookIssue.objects.filter(book=self).count() # Counts the number of BookIssue records that are related to this book, which represents the number of copies currently issued out to users
        return 0 # If the book instance does not have a primary key (i.e., it has not been saved to the database), returns 0 as there can be no issued copies for an unsaved book

    
    def copies_available(self): # Helper method to calculate the number of copies currently available for issue by subtracting the number of issued copies from the total copies, providing a dynamic way to track availability without needing a separate field in the database 
        if self.pk: # Checks if the book instance has a primary key (i.e., it has been saved to the database) before attempting to calculate available copies, ensuring that the method only operates on valid book records 
            return max(self.copies - self.copies_issued(), 0) # Calculates the number of available copies by subtracting the number of issued copies from the total copies, and ensures that the result is not negative by using max with 0
        return self.copies # If the book instance does not have a primary key (i.e., it has not been saved to the database), returns the total number of copies as the available copies, since there can be no issued copies for an unsaved book

    def clean(self): # Defines a custom clean method to perform validation before saving the Book model, ensuring that all required fields are properly validated and that the data integrity of the book records is maintained
            # Title empty
        if not self.title or not self.title.strip(): # Checks if the title is empty or contains only whitespace
            raise ValidationError({ # Raises a validation error with a custom message if the title is invalid 
                'title': "Book title cannot be empty. Please enter a title to continue." # Custom error message for an empty book title, guiding the user to provide a valid title for the book record
            })

        # Author empty
        if not self.author or not self.author.strip(): # Checks if the author is empty or contains only whitespace
            raise ValidationError({ # Raises a validation error with a custom message if the author is invalid #
                'author': "Author name cannot be empty. Please enter an author to continue." # Custom error message for an empty author name, guiding the user to provide a valid author for the book record
            })

        # Genre empty
        if not self.genre: # Checks if the genre is not set (i.e., it is None), which is not allowed since the genre field cannot be blank 
            raise ValidationError({ # Raises a validation error with a custom message if the genre is not selected, guiding the user to select a genre for the book record
                'genre': "Please select a genre for this book." # Custom error message for a missing genre, guiding the user to select a genre for the book record
            })

        # Copies cannot be zero
        if self.copies is None or self.copies <= 0: # Checks if the number of copies is None or less than or equal to 0, which is not allowed since a book must have at least one copy available in the library
            raise ValidationError({ # Raises a validation error with a custom message if the number of copies is invalid, guiding the user to provide a valid number of copies for the book record
                'copies': "Copies must be at least 1. A book cannot have zero copies." # Custom error message for an invalid number of copies, guiding the user to provide a valid number of copies for the book record
            })

        # Year published cannot be in the future
        if self.year_published and self.year_published > timezone.now().date(): # Checks if the year published is set and is greater than the current date, which is not allowed since a book cannot be published in the future
            raise ValidationError({ # Raises a validation error with a custom message if the year published is in the future, guiding the user to provide a valid publication year for the book record
                'year_published': "Year published cannot be in the future." # Custom error message for a future publication year, guiding the user to provide a valid publication year for the book record
            }) 

        if not self.year_published: # Checks if the year published is not set (i.e., it is None), which is not allowed since the publication year is a required field for the book record
            raise ValidationError({ # Raises a validation error with a custom message if the year published is not provided, guiding the user to enter a publication year for the book record
                'year_published': "Year published cannot be empty, please enter a date" # Custom error message for a missing publication year, guiding the user to enter a publication year for the book record
           })  

        if Book.objects.filter( # Checks if another book with the same title and author (case‑insensitive) already exists in the database, excluding the current instance
            title__iexact=self.title.strip(), # Case‑insensitive match on title, ignoring leading/trailing whitespace
            author__iexact=self.author.strip() # Case‑insensitive match on author, ignoring leading/trailing whitespace
        ).exclude(pk=self.pk).exists(): # Excludes the current instance (if it exists) from the check to allow updates without false positives
            raise ValidationError("This book already exists in the system.") #
        
        if self.copies < self.copies_issued(): #    Checks if the number of copies is less than the number of copies currently issued, which is not allowed since the library cannot have fewer total copies than the number of copies that are currently issued out to users
            raise ValidationError({ # Raises a validation error with a custom message if the number of copies is less than the number of issued copies, guiding the user to provide a valid number of copies that accommodates all currently issued copies
                'copies': f"Cannot set copies below currently issued count ({self.copies_issued()})." # Custom error message indicating the minimum number of copies required based on the current number of issued copies, guiding the user to provide a valid number of copies for the book record
            }) 

    def __str__(self): # Defines the string representation of the Book model, which is used in the Django admin and other places where the object is represented as a string
        return self.title + " by " + self.author # Returns the book's title and author as the string representation of the Book object, making it easier to identify books in lists and dropdowns

class BookIssue(models.Model): # Defines the BookIssue model representing the issuance of books to users in the library, tracking which user has issued which book and when it is due for return
  issue_id = models.AutoField(primary_key=True) # Auto‑incrementing primary key uniquely identifying each book issue record
  user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=False) #    Establishes a foreign key relationship to the User model, allowing each book issue to be associated with a user. If the user is deleted, the related book issues will also be deleted (CASCADE). The user field cannot be blank but can be null in the database.
  book = models.ForeignKey(Book, on_delete=models.CASCADE, null=True, blank=False) # Establishes a foreign key relationship to the Book model, allowing each book issue to be associated with a book. If the book is deleted, the related book issues will also be deleted (CASCADE). The book field cannot be blank but can be null in the database.
  issue_date = models.DateField(auto_now_add=True) # Stores the date when the book was issued, automatically set to the current date when the record is created and not editable thereafter
  return_by = models.DateField(default=default_return_date, blank=True, null=True, editable=False) # Stores the date by which the book should be returned, with a default value calculated by the helper function to be 3 weeks from the issue date. This field is not editable in the admin interface and can be blank or null in the database to allow for flexibility in handling returns.
  max_issues_allowed = models.PositiveIntegerField(default=default_max_issues_allowed, editable=False) # Stores the maximum number of issues allowed for the user at the time of issuing the book, with a default value set by the helper function and not editable in the admin interface. This field is used to track the user's borrowing limit at the time of issue, allowing for accurate enforcement of borrowing policies even if the user's max_issues_allowed changes later on.

  def __str__(self):# Defines the string representation of the BookIssue model, which is used in the Django admin and other places where the object is represented as a string 
    return f"{self.user} issued {self.book} on {self.issue_date} return date {self.return_by}" # Returns a string that includes the user's name, the book's title, the issue date, and the return date as the string representation of the BookIssue object, making it easier to identify book issues in lists and dropdowns
  
  def clean(self): # Defines a custom clean method to perform validation before saving the BookIssue model, ensuring that all required fields are properly validated and that the data integrity of the book issue records is maintained 
    if not self.user: # Checks if the user field is not set (i.e., it is None), which is not allowed since a book issue must be associated with a user
        raise ValidationError({ # Raises a validation error with a custom message if the user is not selected, guiding the user to select a user for the book issue record
            'user': "Please select a user to issue the book." # Custom error message for a missing user, guiding the user to select a user for the book issue record
        })
    if not self.book: # Checks if the book field is not set (i.e., it is None), which is not allowed since a book issue must be associated with a book
        raise ValidationError({ # Raises a validation error with a custom message if the book is not selected, guiding the user to select a book for the book issue record
            'book': "Please select a book to issue." # Custom error message for a missing book, guiding the user to select a book for the book issue record 
        })   
    if self.user and self.user.max_issues_allowed <= 0: # Checks if the user is set and their max_issues_allowed is less than or equal to 0, which means they have no remaining issues allowed and cannot issue another book
        raise ValidationError({ # Raises a validation error with a custom message if the user has no remaining issues allowed, guiding the user to understand that they cannot issue another book until they return some of their currently issued books
            'user': f"{self.user} has no remaining issues" # Custom error message indicating that the user has no remaining issues allowed, guiding the user to understand that they cannot issue another book until they return some of their currently issued books
        })

    if self.book: # Checks if the book field is set before performing availability validation, ensuring that the validation only runs when a book is selected for issue
      issued_count = BookIssue.objects.filter(book=self.book).exclude(pk=self.pk).count() # Counts the number of BookIssue records for the selected book, excluding the current instance (if it exists) to allow for updates without false positives. This count represents the number of copies currently issued out to users.
      if issued_count >= self.book.copies: # Checks if the number of issued copies is greater than or equal to the total number of copies available for the book, which means there are no copies available for issue
        raise ValidationError({ # Raises a validation error with a custom message if there are no copies of the book available for issue, guiding the user to understand that they cannot issue this book until some copies are returned
            'book': f"No copies of '{self.book.title}' are available for issue." # Custom error message indicating that there are no copies of the selected book available for issue, guiding the user to understand that they cannot issue this book until some copies are returned
        })  
    super().clean() # Calls the parent clean method to ensure any built‑in validation is executed after the custom validation logic, maintaining the integrity of the validation process and allowing for any additional validation defined in the parent class to be executed as well

  def save(self, *args, **kwargs): # Overrides the save method to include custom logic for handling the issuance of books, such as setting default values, updating the user's max_issues_allowed, and creating a BorrowRecord for tracking the issue and return of the book
    is_new = self.pk is None  # Determines if the book issue record is being created for the first time (i.e., it does not have a primary key yet) to ensure that certain actions, such as updating max_issues_allowed and creating a BorrowRecord, only occur on the initial creation of the book issue record and not on subsequent updates

    self.full_clean() # Calls full_clean to perform validation before saving the record, ensuring that all validation logic defined in the clean method is executed and that the data integrity of the book issue record is maintained before it is saved to the database
  
    if not self.issue_date: # Checks if the issue_date is not set (i.e., it is None), which should not happen since issue_date is set to auto_now_add, but this check ensures that the issue_date is always set to a valid value before saving
        self.issue_date = timezone.now().date() # Sets the issue_date to the current date if it is not already set, ensuring that the book issue record always has a valid issue date before it is saved to the database

    if is_new: # Checks if the book issue record is being created for the first time to set the return_by date based on the issue_date, ensuring that the return_by date is correctly calculated and set when a new book issue record is created
        # Set return date only on creation #    
        self.return_by = self.issue_date + timedelta(weeks=3) # Sets the return_by date to be 3 weeks from the issue_date, providing a default return date for the issued book based on the library's borrowing policy

    super().save(*args, **kwargs) # Calls the parent save method to save the book issue record to the database after all custom logic and validation has been executed, ensuring that the record is properly saved and that any additional logic defined in the parent class's save method is also executed

    # After saving the issue, reduce user's max_issues_allowed
    if is_new: # Checks if the book issue record is being created for the first time to update the user's max_issues_allowed, ensuring that the user's borrowing limit is accurately enforced when they issue a new book
        user = self.user # Retrieves the user associated with the book issue record to update their max_issues_allowed, allowing for accurate tracking of the user's borrowing limit after issuing a book
        if user.max_issues_allowed > 0: # Checks if the user's max_issues_allowed is greater than 0 before decrementing it, ensuring that the value does not go negative and that the borrowing limit is properly enforced
            user.max_issues_allowed -= 1 # Decrements the user's max_issues_allowed by 1 to reflect that they have issued a book, enforcing the borrowing limit and ensuring that the user cannot issue more books than allowed
            user.save() # Saves the updated user record to the database after modifying max_issues_allowed, ensuring that the change is persisted and that the user's borrowing limit is accurately reflected in the database

    if is_new: # Checks if the book issue record is being created for the first time to create a BorrowRecord for tracking the issue and return of the book, ensuring that a BorrowRecord is only created when a new book issue is made and not on subsequent updates to the book issue record
        BorrowRecord.objects.create( # Creates a new BorrowRecord to track the borrowing of the book, allowing for accurate tracking of the issue and return history for each book and user
            user=self.user, # Associates the BorrowRecord with the user who issued the book, allowing for tracking of which user borrowed which book
            book=self.book, # Associates the BorrowRecord with the book that was issued, allowing for tracking of which book was borrowed by which user
            issue_date=self.issue_date, # Sets the issue_date of the BorrowRecord to match the issue_date of the BookIssue, ensuring consistency in tracking the borrowing history
    ) 



class BookReturn(models.Model): # Defines the BookReturn model representing the return of books by users in the library, tracking which user returned which book and when it was returned, as well as calculating any fines for late returns
   return_id = models.AutoField(primary_key=True) # Auto‑incrementing primary key uniquely identifying each book return record
   user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=False) # Establishes a foreign key relationship to the User model, allowing each book return to be associated with a user. If the user is deleted, the related book returns will also be deleted (CASCADE). The user field cannot be blank but can be null in the database.
   book = models.ForeignKey(Book, on_delete=models.CASCADE, null=True, blank=False) # Establishes a foreign key relationship to the Book model, allowing each book return to be associated with a book. If the book is deleted, the related book returns will also be deleted (CASCADE). The book field cannot be blank but can be null in the database.
   return_date = models.DateField( null=True, blank=False) # Stores the date when the book was returned, allowing for null values to accommodate cases where the return date is not provided at the time of record creation. The field cannot be blank in forms to ensure that a return date is always provided when creating a book return record.
 
   def clean(self): # Defines a custom clean method to perform validation before saving the BookReturn model, ensuring that all required fields are properly validated, that the return is valid based on the user's borrowing history, and that the return date is logical in relation to the issue date
       super().clean() # Calls the parent clean method to ensure any built‑in validation is executed first, maintaining the integrity of the validation process and allowing for any additional validation defined in the parent class to be executed as well
       if not self.user: # Checks if the user field is not set (i.e., it is None), which is not allowed since a book return must be associated with a user
           raise ValidationError({ # Raises a validation error with a custom message if the user is not selected, guiding the user to select a user for the book return record
               'user': "Please select a user. A return must be linked to a user." # Custom error message for a missing user, guiding the user to select a user for the book return record
           })

       # Book empty 
       if not self.book: # Checks if the book field is not set (i.e., it is None), which is not allowed since a book return must be associated with a book 
           raise ValidationError({ #    Raises a validation error with a custom message if the book is not selected, guiding the user to select a book for the book return record
               'book': "Please select a book. Only issued books can be returned." # Custom error message for a missing book, guiding the user to select a book for the book return record and indicating that only issued books can be returned
           })
       if not self.return_date: # Checks if the return_date is not set (i.e., it is None), which is not allowed since a book return must have a return date to be valid
           raise ValidationError({ # Raises a validation error with a custom message if the return date is not provided, guiding the user to enter a return date for the book return record
              'return_date':"please enter a return date to continue" # Custom error message for a missing return date, guiding the user to enter a return date for the book return record to ensure that the return is properly tracked and that any fines can be calculated based on the return date
           })
       
       if self.user and self.book: # Checks if both the user and book fields are set before performing validation to ensure that the validation logic only runs when both a user and a book are selected for the return, allowing for accurate validation of the return based on the user's borrowing history
           active_issue = BookIssue.objects.filter(user=self.user, book=self.book).first() # Checks if there is an active BookIssue for the given user and book, which indicates that the user has currently issued this book and is eligible to return it. This query looks for any BookIssue records that match the user and book, and retrieves the first one if it exists.
           if not active_issue: # If no active BookIssue is found for the user and book, it means that the user has not issued this book or has already returned it, and therefore cannot return it again. In this case, a validation error is raised to indicate that the return is invalid because there is no corresponding issue record for this user and book combination.
               raise ValidationError({ # Raises a validation error with a custom message if there is no active issue record for the user and book, guiding the user to understand that they cannot return a book that they have not issued or have already returned
                   'book': f"This user has not issued '{self.book.title}'. Only issued books can be returned." # Custom error message indicating that the user has not issued the selected book and therefore cannot return it, guiding the user to understand that they can only return books that they have currently issued
               })
       record = BorrowRecord.objects.filter( # Retrieves the active BorrowRecord for the given user and book, which is used to validate the return date against the issue date and to calculate any fines for late returns. This query looks for a BorrowRecord that matches the user and book, and where the return_date is null (indicating that the book has not been returned yet), and retrieves the first one if it exists.
           user=self.user, # Filters BorrowRecord records to find those that match the user associated with the book return, allowing for validation of the return based on the user's borrowing history
           book=self.book, # Filters BorrowRecord records to find those that match the book associated with the book return, allowing for validation of the return based on the specific book being returned
           return_date__isnull=True # Filters BorrowRecord records to find those where the return_date is null, indicating that the book has not been returned yet and that this record represents an active borrowing of the book by the user, which is necessary for validating the return and calculating any fines based on the return date in relation to the issue date
        ).first() # Retrieves the first BorrowRecord that matches the specified filters, which represents the active borrowing of the book by the user that is being returned. This record is used for validating the return date and calculating fines if the return is late.
       
       return_date = self.return_date # Retrieves the return_date from the BookReturn instance to validate it against the issue_date from the BorrowRecord, ensuring that the return date is logical and not earlier than the issue date, which would indicate an invalid return record
       issue_date = record.issue_date # Retrieves the issue_date from the BorrowRecord to validate it against the return_date from the BookReturn, ensuring that the return date is logical and not earlier than the issue date, which would indicate an invalid return record

       if isinstance(return_date, datetime): # Checks if the return_date is an instance of datetime, which can happen if the return_date is provided as a datetime object instead of a date object. This check ensures that the validation logic can handle both date and datetime inputs for the return_date.
          return_date = return_date.date() # If the return_date is a datetime object, it converts it to a date object by calling the date() method, ensuring that the validation logic can compare the return_date and issue_date as date objects regardless of how the return_date was provided.

       if isinstance(issue_date, datetime): # Checks if the issue_date is an instance of datetime, which can happen if the issue_date is stored as a datetime object in the database. This check ensures that the validation logic can handle both date and datetime inputs for the issue_date.
           issue_date = issue_date.date() # If the issue_date is a datetime object, it converts it to a date object by calling the date() method, ensuring that the validation logic can compare the return_date and issue_date as date objects regardless of how the issue_date is stored in the database.

       if return_date < issue_date: # Checks if the return_date is earlier than the issue_date, which would indicate an invalid return record since a book cannot be returned before it is issued. This validation ensures that the return date is logical in relation to the issue date and helps maintain the integrity of the borrowing and returning records in the system.
           raise ValidationError({ # Raises a validation error with a custom message if the return date is earlier than the issue date, guiding the user to enter a valid return date that is on or after the issue date for the book return record
               'return_date': "Return date cannot be earlier than the issue date." # Custom error message indicating that the return date cannot be earlier than the issue date, guiding the user to enter a valid return date for the book return record
           })

   def save(self, *args, **kwargs): # Overrides the save method to include custom logic for handling the return of books, such as validating the return, updating the user's max_issues_allowed, and calculating any fines for late returns. This method ensures that all necessary actions are taken when a book return record is saved, maintaining the integrity of the borrowing and returning process in the library system.
       is_new  = self.pk is None # Determines if the book return record is being created for the first time (i.e., it does not have a primary key yet) to ensure that certain actions, such as updating max_issues_allowed and calculating fines, only occur on the initial creation of the book return record and not on subsequent updates to the record. This allows for accurate handling of the return process and ensures that fines are only calculated when a new return is made.

       self.full_clean() # Calls full_clean to perform validation before saving the record, ensuring that all validation logic defined in the clean method is executed and that the data integrity of the book return record is maintained before it is saved to the database
       super().save(*args, **kwargs) # Calls the parent save method to save the book return record to the database after all custom logic and validation has been executed, ensuring that the record is properly saved and that any additional logic defined in the parent class's save method is also executed
       # Remove the active BookIssue and update BorrowRecord after return
       record = None # Initializes the record variable to None, which will be used to store the active BorrowRecord associated with the user and book being returned. This variable is used later in the method to check if a valid BorrowRecord was found for the return and to perform updates based on that record.
       if is_new: # Checks if the book return record is being created for the first time to perform the necessary actions for processing the return, such as removing the active BookIssue and updating the BorrowRecord. This ensures that these actions are only taken when a new return is made and not on subsequent updates to the return record.
          active_issue = BookIssue.objects.filter(user=self.user, book=self.book # Checks for an active BookIssue for the given user and book, which indicates that the user has currently issued this book and is eligible to return it. This query looks for any BookIssue records that match the user and book, and retrieves the first one if it exists. If an active issue is found, it will be deleted to reflect that the book has been returned.
          ).order_by('issue_date').first() # Orders the BookIssue records by issue_date to ensure that if there are multiple issues of the same book by the same user (which should not happen but is checked for safety), the earliest one is returned as the active issue to be removed upon return.
          if active_issue: #    Checks if an active BookIssue was found for the user and book, which means that there is a valid issue record that can be removed to reflect the return of the book. If no active issue is found, it means that there is an inconsistency in the data (since the clean method should have prevented this), but this check ensures that the code does not attempt to delete a non-existent issue record.
              active_issue.delete() # Deletes the active BookIssue record to reflect that the book has been returned, ensuring that the issue record is removed from the database and that the book is no longer considered issued to the user.

          record = BorrowRecord.objects.filter(  # Retrieves the active BorrowRecord for the given user and book, which is used to update the return_date and calculate any fines for late returns. This query looks for a BorrowRecord that matches the user and book, and where the return_date is null (indicating that the book has not been returned yet), and retrieves the first one if it exists.
              user=self.user, # Filters BorrowRecord records to find those that match the user associated with the book return, allowing for updating the return date and calculating fines based on the user's borrowing history
              book=self.book, # Filters BorrowRecord records to find those that match the book associated with the book return, allowing for updating the return date and calculating fines based on the specific book being returned
              return_date__isnull=True # Filters BorrowRecord records to find those where the return_date is null, indicating that the book has not been returned yet and that this record represents an active borrowing of the book by the user, which is necessary for updating the return date and calculating any fines based on the return date in relation to the issue date
          ).first() # Retrieves the first BorrowRecord that matches the specified filters, which represents the active borrowing of the book by the user that is being returned. This record is used for updating the return date and calculating fines if the return is late.
          if record: # Checks if a valid BorrowRecord was found for the user and book, which means that there is an active borrowing record that can be updated with the return date and used for calculating fines. If no record is found, it means that there is an inconsistency in the data (since the clean method should have prevented this), but this check ensures that the code does not attempt to update a non-existent record.
              record.return_date = self.return_date # Updates the return_date of the BorrowRecord to match the return_date of the BookReturn, ensuring that the borrowing record is updated to reflect the return of the book and that any fines can be calculated based on the return date in relation to the issue date
              
              record.save() # Saves the updated BorrowRecord to the database after setting the return_date, ensuring that the change is persisted and that the borrowing history accurately reflects the return of the book by the user. This also allows for any fines to be calculated based on the return date in relation to the issue date when the record is saved.


       if record: # Checks if a valid BorrowRecord was found for the user and book, which means that there is an active borrowing record that can be used to calculate fines for late returns. If no record is found, it means that there is an inconsistency in the data (since the clean method should have prevented this), but this check ensures that the code does not attempt to calculate fines based on a non-existent record.
        due_date = record.issue_date + timedelta(weeks=3) # Calculates the due date for the borrowed book based on the issue_date from the BorrowRecord, adding 3 weeks to the issue_date to determine when the book was due for return according to the library's borrowing policy. This due date is used to compare against the return_date to determine if the return is late and if any fines should be calculated.

        if self.return_date > due_date: # Checks if the return_date from the BookReturn is later than the calculated due_date, which indicates that the book was returned late. If the return is late, a fine will be calculated based on the number of days late and a predefined fine rate.
            # Returned late → calculate fine
            days_late = (self.return_date - due_date).days # Calculates the number of days late by subtracting the due_date from the return_date and getting the number of days from the resulting timedelta object. This value is used to calculate the fine amount based on a predefined fine rate per day.
            record.fine_amount = days_late * 0.50 # Calculates the fine amount by multiplying the number of days late by a predefined fine rate (in this case, $0.50 per day), and sets the fine_amount field of the BorrowRecord to this calculated value, allowing for accurate tracking of fines for late returns in the borrowing history. This fine amount can be used for reporting and enforcement of library policies regarding late returns.
        else: # 
            # Returned on time → fine stays 0.00    # If the return is not late (i.e., the return_date is on or before the due_date), the fine_amount remains at its default value of 0.00, indicating that there are no fines for this return since it was made within the allowed borrowing period.
            record.fine_amount = 0.00 # Sets the fine_amount to 0.00 for returns that are made on time, ensuring that no fines are applied for returns that are within the allowed borrowing period according to the library's policies. This allows for accurate tracking of fines and ensures that users are not unfairly charged for timely returns.
 
        record.save() # Saves the updated BorrowRecord to the database after calculating the fine amount (if applicable), ensuring that the change is persisted and that the borrowing history accurately reflects any fines for late returns. This also allows for accurate reporting of fines and enforcement of library policies regarding late returns.

        user = self.user # Retrieves the user associated with the book return to update their max_issues_allowed, allowing for accurate tracking of the user's borrowing limit after returning a book. This ensures that the user can issue new books if they have returned some of their currently issued books and have available issues allowed.
        user.max_issues_allowed += 1 # Increments the user's max_issues_allowed by 1 to reflect that they have returned a book, allowing them to issue new books if they have returned some of their currently issued books and have available issues allowed. This enforces the borrowing limit and ensures that users can only have a certain number of books issued at a time based on their max_issues_allowed.
        user.save() # Saves the updated user record to the database after modifying max_issues_allowed, ensuring that the change is persisted and that the user's borrowing limit is accurately reflected in the database, allowing for accurate enforcement of borrowing policies when the user attempts to issue new books after returning some of their currently issued books.


   def __str__(self): # Defines the string representation of the BookReturn model, which is used in the Django admin and other places where the object is represented as a string. This method provides a human-readable representation of the book return record, making it easier to identify returns in lists and dropdowns.
    user = self.user if hasattr(self, "user") else "Unknown user" # Retrieves the user associated with the book return to include in the string representation, providing context about who made the return. If the user attribute is not set (which should not happen due to validation, but is checked for safety), it defaults to "Unknown user" to ensure that the string representation can still be generated without errors. 
    book = self.book if hasattr(self, "book") else "Unknown book" # Retrieves the book associated with the book return to include in the string representation, providing context about which book was returned. If the book attribute is not set (which should not happen due to validation, but is checked for safety), it defaults to "Unknown book" to ensure that the string representation can still be generated without errors.
    return f"{user} returned {book} on {self.return_date}" # Returns a string that includes the user's name, the book's title, and the return date as the string representation of the BookReturn object, making it easier to identify book returns in lists and dropdowns. This provides a clear and concise summary of the return record for easy identification in the admin interface and other parts of the application where the BookReturn object is represented as a string.
   
  
                
class BorrowRecord(models.Model): # Defines the BorrowRecord model representing the history of book borrowings by users in the library, tracking which user borrowed which book, when it was issued, when it was returned, and any fines for late returns. This model serves as a historical record of all borrowing activity in the library system.
    record_id = models.AutoField(primary_key=True) # Auto‑incrementing primary key uniquely identifying each borrow record
    book = models.ForeignKey(Book, on_delete=models.CASCADE) # Establishes a foreign key relationship to the Book model, allowing each borrow record to be associated with a book. If the book is deleted, the related borrow records will also be deleted (CASCADE). The book field cannot be blank but can be null in the database.
    user = models.ForeignKey(User, on_delete=models.CASCADE) # Establishes a foreign key relationship to the User model, allowing each borrow record to be associated with a user. If the user is deleted, the related borrow records will also be deleted (CASCADE). The user field cannot be blank but can be null in the database.
    issue_date = models.DateField(auto_now_add=True) # Stores the date when the book was issued, automatically set to the current date when the record is created. This field is not editable in the admin interface and cannot be blank or null in the database to ensure that every borrow record has a valid issue date.
    return_date = models.DateField(blank=True, null=True) # Stores the date when the book was returned, allowing for blank and null values to accommodate cases where the return date is not provided at the time of record creation (e.g., when a book is issued but not yet returned). This field can be updated later when the book is returned to reflect the return date in the borrowing history.
    fine_amount = models.DecimalField(max_digits=6, decimal_places=2, default=0.00) # Stores the fine amount for late returns, allowing for a maximum of 9999.99 in fines. This field is automatically calculated based on the return date and the due date when a book is returned, and it defaults to 0.00 for returns that are made on time. This allows for accurate tracking of fines for late returns in the borrowing history.
    def __str__(self): # Defines the string representation of the BorrowRecord model, which is used in the Django admin and other places where the object is represented as a string. This method provides a human-readable representation of the borrow record, making it easier to identify borrow records in lists and dropdowns.
        return f"{self.user} borrowed {self.book} on {self.issue_date} and returned on {self.return_date}" # Returns a string that includes the user's name, the book's title, the issue date, and the return date as the string representation of the BorrowRecord object, making it easier to identify borrow records in lists and dropdowns. This provides a clear and concise summary of the borrowing history for easy identification in the admin interface and other parts of the application where the BorrowRecord object is represented as a string.