from django.contrib import admin

from .models import Genre, User, Book, BookIssue, BookReturn
# BookIssues, BookReturns, Borrow_record

class BookIssueAdmin(admin.ModelAdmin): # this class 
    readonly_fields = ('issue_date', 'return_by')
    fields = ('user', 'book', 'return_by', 'max_books_allowed')

    def get_changeform_initial_data(self, request):
        initial = super().get_changeform_initial_data(request)
        if 'return_by' not in initial:
            initial['return_by'] = BookIssue.return_by.field.default()
        return initial

admin.site.register(Genre)
admin.site.register(User)
admin.site.register(Book)
admin.site.register(BookIssue, BookIssueAdmin)
admin.site.register(BookReturn)
# admin.site.register(Borrow_record)

# Register your models here.
