from datetime import timedelta
from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator
from django.db import models
from django.utils import timezone

def default_return_date(): #this is for the return_date, automatically sets the return date to 3 weeks after the issue date
    return timezone.now().date() + timedelta(weeks=3)

#22014, password is 22014

class Genre(models.Model):
    genre_id = models.AutoField(primary_key=True)
    genre_name = models.CharField(max_length=100)
    def __str__(self):
        return self.genre_name
    

class User(models.Model):
    user_id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True, blank=False, null=False)
    phone = models.CharField(max_length=15, blank=False, null=False)
    max_books_allowed = models.IntegerField(validators=[MaxValueValidator(3)])
    def clean(self):
      if not self.first_name.strip():
        raise ValidationError("First namecannot be empty, please enter a first name to continue")
      if not self.last_name.strip():
        raise ValidationError("Last name cannot be empty, please enter a last name to continue")
      if not self.email.strip():
        raise ValidationError("Email cannot be empty, please enter an email to continue")
      if not self.phone.strip():
        raise ValidationError("Phone number cannot be empty, please enter a phone number to continue")
      allowed = set("0123456789 -.")
      if not all(char in allowed for char in self.phone):
        raise ValidationError("Phone number must contain only, digits, spaces, periods or -,  Letters are not allowed.")

    def __str__(self):
        return self.first_name + " " + self.last_name


class Book(models.Model):
    book_id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=100)
    author = models.CharField(max_length=100)
    genre = models.ForeignKey(Genre, on_delete=models.CASCADE)
    year_published = models.DateField(blank=True, null=True)
    # is_borrowed = models.BooleanField(default=False)
    def __str__(self):
        return self.title + " by " + self.author

class BookIssue(models.Model):
  issue_id = models.AutoField(primary_key=True)
  user = models.ForeignKey(User, on_delete=models.CASCADE)
  book = models.ForeignKey(Book, on_delete=models.CASCADE)
  issue_date = models.DateField(auto_now_add=True)
  return_by = models.DateField(default=default_return_date, blank=True, null=True, editable=False)
  max_books_allowed = models.IntegerField(validators=[MaxValueValidator(3)])
  def __str__(self):
    return f"{self.user} issued {self.book} on {self.issue_date} return date {self.return_by}"

  def save(self, *args, **kwargs):
    if not self.issue_date:
      self.issue_date = timezone.now().date()
    self.return_by = self.issue_date + timedelta(weeks=3)
    super().save(*args, **kwargs)

class BookReturn(models.Model):
   return_id = models.AutoField(primary_key=True)
   user = models.ForeignKey(User, on_delete=models.CASCADE)
   book = models.ForeignKey(Book, on_delete=models.CASCADE)
   return_date = models.DateField(auto_now_add=True)
   def __str__(self):
      return f"{self.user} returned {self.book} on {self.return_date}"
   
   
   
# class Borrow_record(models.Model):