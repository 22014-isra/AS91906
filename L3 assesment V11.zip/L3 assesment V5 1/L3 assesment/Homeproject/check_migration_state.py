import sqlite3
conn=sqlite3.connect('db.sqlite3')
cur=conn.cursor()
for row in cur.execute("SELECT app, name, applied FROM django_migrations WHERE app='myapp' ORDER BY name"):
    print(row)
print('\nSchema for myapp_book:')
for row in cur.execute("PRAGMA table_info(myapp_book)"):
    print(row)
print('\nSchema for myapp_bookissues if exists:')
for row in cur.execute("SELECT name, sql FROM sqlite_master WHERE type='table' AND name='myapp_bookissues'"):
    print(row)
conn.close()
