from datetime import timedelta
from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator
from django.db import models
from django.utils import timezone

def default_return_date(): #this is for the return_date, automatically sets the return date to 3 weeks after the issue date
    return timezone.now().date() + timedelta(weeks=3)

def default_max_issues_allowed(): #this is for the max_issues_allowed, automatically sets the max_issues_allowed to 3
    return 3

#22014, password is 22014

class Genre(models.Model):
    genre_id = models.AutoField(primary_key=True)
    genre_name = models.CharField(max_length=100)
    def __str__(self):
        return self.genre_name
    

class User(models.Model):
    user_id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True, blank=False, null=False)
    phone = models.CharField(max_length=15, blank=False, null=False)
    max_issues_allowed = models.PositiveIntegerField(default=default_max_issues_allowed, editable=False)
    def clean(self):
      if not self.first_name.strip():
        raise ValidationError("First namecannot be empty, please enter a first name to continue")
      if not self.last_name.strip():
        raise ValidationError("Last name cannot be empty, please enter a last name to continue")
      if not self.email.strip():
        raise ValidationError("Email cannot be empty, please enter an email to continue")
      if not self.phone.strip():
        raise ValidationError("Phone number cannot be empty, please enter a phone number to continue")
      allowed = set("0123456789 -.")
      if not all(char in allowed for char in self.phone):
        raise ValidationError("Phone number must contain only, digits, spaces, periods or -,  Letters are not allowed.")

    def __str__(self):
        return self.first_name + " " + self.last_name


class Book(models.Model):
    book_id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=100)
    author = models.CharField(max_length=100)
    genre = models.ForeignKey(Genre, on_delete=models.CASCADE)
    year_published = models.DateField(blank=True, null=True)
    copies = models.PositiveIntegerField(default=1)

    def copies_issued(self):
        if self.pk:
            return BookIssue.objects.filter(book=self).count()
        return 0

    
    def copies_available(self):
        if self.pk:
            return max(self.copies - self.copies_issued(), 0)
        return self.copies

    def clean(self):
        if self.copies < self.copies_issued():
            raise ValidationError({
                'copies': f"Cannot set copies below currently issued count ({self.copies_issued()})."
            })

    def __str__(self):
        return self.title + " by " + self.author

class BookIssue(models.Model):
  issue_id = models.AutoField(primary_key=True)
  user = models.ForeignKey(User, on_delete=models.CASCADE)
  book = models.ForeignKey(Book, on_delete=models.CASCADE)
  issue_date = models.DateField(auto_now_add=True)
  return_by = models.DateField(default=default_return_date, blank=True, null=True, editable=False)
  max_issues_allowed = models.PositiveIntegerField(default=default_max_issues_allowed, editable=False)

  def __str__(self):
    return f"{self.user} issued {self.book} on {self.issue_date} return date {self.return_by}"
  
  def clean(self):
    if self.user and self.user.max_issues_allowed <= 0:
        raise ValidationError({
            'user': f"{self.user} has no remaining issues"
        })

    if self.book:
      issued_count = BookIssue.objects.filter(book=self.book).exclude(pk=self.pk).count()
      if issued_count >= self.book.copies:
        raise ValidationError({
            'book': f"No copies of '{self.book.title}' are available for issue."
        })
    super().clean()

  def save(self, *args, **kwargs):
    is_new = self.pk is None  # Only run logic on creation

    self.full_clean()

    if not self.issue_date:
        self.issue_date = timezone.now().date()

    if is_new:
        # Set return date only on creation
        self.return_by = self.issue_date + timedelta(weeks=3)

    super().save(*args, **kwargs)

    # After saving the issue, reduce user's max_issues_allowed
    if is_new:
        user = self.user
        if user.max_issues_allowed > 0:
            user.max_issues_allowed -= 1
            user.save()

    if is_new:
        BorrowRecord.objects.create(
            user=self.user,
            book=self.book,
            issue_date=self.issue_date,
            unavailable=True,
            available=False
    )



class BookReturn(models.Model):
   return_id = models.AutoField(primary_key=True)
   user = models.ForeignKey(User, on_delete=models.CASCADE)
   book = models.ForeignKey(Book, on_delete=models.CASCADE)
   return_date = models.DateField(auto_now_add=True)

   def clean(self):
       if self.user and self.book:
           active_issue = BookIssue.objects.filter(user=self.user, book=self.book).first()
           if not active_issue:
               raise ValidationError({
                   'book': f"This user has not issued '{self.book.title}'. Only issued books can be returned."
               })
       super().clean()

   def save(self, *args, **kwargs):
       is_new  = self.pk is None

       self.full_clean()
       super().save(*args, **kwargs)
       # Remove the active BookIssue and update BorrowRecord after return
       if is_new:
          active_issue = BookIssue.objects.filter(user=self.user, book=self.book
          ).order_by('issue_date').first()
          if active_issue:
              active_issue.delete()

          record = BorrowRecord.objects.filter(
              user=self.user,
              book=self.book,
              return_date__isnull=True
          ).first()
          if record:
              record.return_date = self.return_date
              record.available = True
              record.unavailable = False
              record.save()


       if record:
          if self.return_date > record.issue_date + timedelta(weeks=3):
              days_late = (self.return_date - (record.issue_date + timedelta(weeks=3))).days
              record.fine_amount = days_late * 0.50
          else:
              record.fine_amount = 0.00
              record.save()
          user = self.user
          user.max_issues_allowed += 1
          user.save()

    #    BookIssue.objects.filter(user=self.user, book=self.book).delete()
    #    BorrowRecord.objects.filter(
    #        user=self.user,
    #        book=self.book,
    #        return_date__isnull=True
    #     ).update(return_date=self.return_date, available=True, unavailable=False)
    #    record = BorrowRecord.objects.filter(
    #        user=self.user,
    #        book=self.book,
    #        return_date__isnull=True
    #    ).first()

    #    if record:
    #         record.return_date = self.return_date
    #         record.available = True
    #         record.unavailable = False
    #         record.save()


   def __str__(self):
      return f"{self.user} returned {self.book} on {self.return_date}"
   
  
                
class BorrowRecord(models.Model):
    record_id = models.AutoField(primary_key=True)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    unavailable = models.BooleanField(default=False)
    available = models.BooleanField(default=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    issue_date = models.DateField()
    return_date = models.DateField(blank=True, null=True)
    fine_amount = models.DecimalField(max_digits=6, decimal_places=2, default=0.00)
    def __str__(self):
        return f"{self.user} borrowed {self.book} on {self.issue_date} and returned on {self.return_date}"