from django.contrib import admin

from .models import Genre, User, Book, BookIssue, BookReturn, BorrowRecord
# BookIssues, BookReturns, Borrow_record

class UserAdmin(admin.ModelAdmin):
    readonly_fields = ('max_issues_allowed',)

class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'genre', 'copies', 'copies_available')
    fields = ('title', 'author', 'genre', 'year_published', 'copies')

class BookIssueAdmin(admin.ModelAdmin): # this class 
    readonly_fields = ('issue_date', 'return_by', 'max_issues_allowed')
    fields = ('user', 'book', 'return_by')

    def get_changeform_initial_data(self, request):
        initial = super().get_changeform_initial_data(request)
        if 'return_by' not in initial:
            initial['return_by'] = BookIssue.return_by.field.default()
        return initial

admin.site.register(Genre)
admin.site.register(User, UserAdmin)
admin.site.register(Book, BookAdmin)
admin.site.register(BookIssue, BookIssueAdmin)
admin.site.register(BookReturn)
admin.site.register(BorrowRecord)

# Register your models here.
