from django import forms
from django.contrib import admin
from django.core.exceptions import ValidationError
from django.db import models

from .models import Genre, User, Book, BookIssue, BookReturn, BorrowRecord


class UserAdmin(admin.ModelAdmin):
    readonly_fields = ('max_issues_allowed',)


class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'genre', 'copies', 'copies_available')
    fields = ('title', 'author', 'genre', 'year_published', 'copies')


class BookIssueAdmin(admin.ModelAdmin):
    list_display = ('user', 'book', 'issue_date', 'return_by')
    readonly_fields = ('issue_date', 'return_by', 'max_issues_allowed')
    fields = ('user', 'book', 'return_by')

    def get_changeform_initial_data(self, request):
        initial = super().get_changeform_initial_data(request)
        if 'return_by' not in initial:
            initial['return_by'] = BookIssue.return_by.field.default()
        return initial


class BookReturnForm(forms.ModelForm):
    class Meta:
        model = BookReturn
        fields = '__all__'

    def clean(self):
        cleaned_data = super().clean()
        user = cleaned_data.get('user')
        book = cleaned_data.get('book')
        if user and book:
            active_issue = BookIssue.objects.filter(user=user, book=book).first()
            if not active_issue:
                raise ValidationError(
                    f"This user has not issued '{book.title}'. Only issued books can be returned."
                )
        return cleaned_data


class BookReturnAdmin(admin.ModelAdmin):
    form = BookReturnForm
    list_display = ('user', 'book', 'return_date')
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "book":
            # Only show books that still have at least one active issue
            kwargs["queryset"] = Book.objects.annotate(
                active_issues=models.Count('bookissue')
            ).filter(active_issues__gt=0)
        return super().formfield_for_foreignkey(db_field, request, **kwargs)

admin.site.register(Genre)
admin.site.register(User, UserAdmin)
admin.site.register(Book, BookAdmin)
admin.site.register(BookIssue, BookIssueAdmin)
admin.site.register(BookReturn, BookReturnAdmin)
admin.site.register(BorrowRecord)
